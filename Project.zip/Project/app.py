from flask import Flask, request, jsonify, render_template, redirect, url_for
from flask_bcrypt import Bcrypt
from flask_mysqldb import MySQL
import base64
from datetime import datetime

app = Flask(__name__)
bcrypt = Bcrypt(app)

# Database Configuration
app.config['MYSQL_HOST'] = '10.70.73.231'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root123'
app.config['MYSQL_DB'] = 'global_employee_db'

mysql = MySQL(app)

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        # Handle form data
        name = request.form['name']
        contact_number = request.form['contact_number']
        home_address = request.form['home_address']
        branch = request.form['branch']
        city = request.form['city']
        designation = request.form['designation']
        password = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')
        photo = request.files['photo'].read()

        conn = mysql.connection
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO Employee (name, contact_number, home_address, branch, city, designation, password)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (name, contact_number, home_address, branch, city, designation, password))
        conn.commit()

        employee_id = cursor.lastrowid

        cursor.execute("""
            INSERT INTO EmployeePhoto (employee_id, photo)
            VALUES (%s, %s)
        """, (employee_id, photo))
        conn.commit()

        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        contact_number = request.form['contact_number']
        password = request.form['password']

        conn = mysql.connection
        cursor = conn.cursor()
        cursor.execute("""
            SELECT employee_id, password FROM Employee WHERE contact_number = %s
        """, (contact_number,))
        user = cursor.fetchone()

        if user and bcrypt.check_password_hash(user[1], password):
            return redirect(url_for('profile', employee_id=user[0]))
        else:
            return jsonify({"message": "Invalid credentials"}), 401

    return render_template('login.html')

@app.route('/profile/<int:employee_id>')
def profile(employee_id):
    conn = mysql.connection
    cursor = conn.cursor()

    cursor.execute("""
        SELECT name, contact_number, home_address, branch, city, designation
        FROM Employee WHERE employee_id = %s
    """, (employee_id,))
    profile = cursor.fetchone()

    cursor.execute("""
        SELECT photo FROM EmployeePhoto WHERE employee_id = %s
    """, (employee_id,))
    photo = cursor.fetchone()

    photo_base64 = base64.b64encode(photo[0]).decode('utf-8') if photo else None

    return render_template('profile.html', profile=profile, photo=photo_base64)

@app.route('/attendance', methods=['GET', 'POST'])
def attendance():
    if request.method == 'POST':
        employee_id = request.form['employee_id']
        photo = request.files['photo'].read()
        latitude = request.form['latitude']
        longitude = request.form['longitude']

        conn = mysql.connection
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO Attendance (employee_id, latitude, longitude, photo)
            VALUES (%s, %s, %s, %s)
        """, (employee_id, latitude, longitude, photo))
        conn.commit()

        return jsonify({"message": "Attendance marked successfully!"})

    return render_template('attendance.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
