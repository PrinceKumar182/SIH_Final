function captureAttendance() {
  navigator.geolocation.getCurrentPosition(function (position) {
      const location = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
      };

      const fileInput = document.getElementById('photoUpload');
      const file = fileInput.files[0];
      const formData = new FormData();
      formData.append('photo', file);
      formData.append('location', JSON.stringify(location));

      fetch('/track_attendance', {
          method: 'POST',
          body: formData,
      })
      .then(response => response.json())
      .then(data => {
          alert(data.status === "success" ? "Attendance Recorded" : "Face Match Failed");
      })
      .catch(error => console.error('Error:', error));
  });
}
